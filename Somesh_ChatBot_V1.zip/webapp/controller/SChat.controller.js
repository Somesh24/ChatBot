jQuery.sap.require("sap.m.CustomListItem");
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.chatbot.Somesh_ChatBot.controller.SChat", {
		
			onAfterRendering: function () {
			this.getBotInstanceId(); //get user uuid of your bot account in recast.ai
			//sap.ui.getCore().byId("buttonBot").attachPress(this.openBot.bind(this)); //attaching press to open chat window
		},

	getBotInstanceId: function () {
			var that = this;
			$.ajax({
				type: "GET",
				url: "https://" + "api.recast.ai/auth/v1/owners/somesh24 ",
				headers: {
					"Authorization": "dc2a902c560ffe38fe709808ba9b8258"
				},
				success: function (data) {
					that.uuid = data.results.owner.id;
				},
				error: function (data) {
					that.botError = data;
				}
			});
		},

        	openBot: function (oEvent) {
			if (!this._obotFrag) {
				this._obotFrag = sap.ui.xmlfragment(this.createId("chatBotFragment"),
					"com.chatbot.Somesh_ChatBot.view.botFrag", this);
				this._obotFrag.attachBeforeOpen(this.onBeforeBotOpen.bind(this));
				var oModel = new sap.ui.model.json.JSONModel({
					data: {}
				});
		    	this._obotFrag.setModel(oModel);
				this._obotFrag.openBy(this.byId('buttonBot'));
				this.chatInput = this.byId(sap.ui.core.Fragment.createId(this.createId("chatBotFragment"), "chat"));
				this.chatInput.attachBrowserEvent("keyup", this.parseText.bind(this), false);
				this.chatInput.addStyleClass("botInput");
			}
			else{
			this.handleChatButton();	
			}
		},
		
			handleChatButton: function (oEvent) {
			// create popover 
			this._obotFrag.getModel().refresh();
			if (!this._obotFrag.isOpen()) {
				this._obotFrag.openBy(this.byId('buttonBot'));
				var oChatList = this.byId(sap.ui.core.Fragment.createId(this.createId("chatBotFragment"), "chat"));
				//this.chatScroll.rerender(true);*/
				if (oChatList.getMaxLength() > 0) {
					this.chatScroll.scrollToElement(oChatList.getItems()[oChatList.getMaxItemsCount() - 1]);
				}
			}
		},

        parseText: function (event) {
        	
			var message;
			if (event.keyCode === 13 && this.chatInput.getValue()) {
				message = this.chatInput.getValue().trim();

				// message is "sent" and triggers bot "response" with small delay
				if (message !== "") {
					this.chatInput.setValue(""); // Clear the value in input after enter key press
					this.createMessage("user", message); 
					// Only respond to one message at a time
					if (!this.isTyping) {
						this.respondTo(message);
					//	var that = this;
						this.isTyping = true;
						setTimeout(function () {
							that.respondTo(message);
						}, Math.random() * (4000) + 1000);
					}
				}
			}
		},

		respondTo:function(message){
			
			var response = "", // String to hold generated response
				responseLength, // number of words in response
				numChars, // number of characters in word
				selectedWord, // index of selected word (by length)
				delay, // chat bot delay in ms
				msgLength, // number of words in @message String
				comma; // optional comma

			// short sentences typically get short responses.
			if (message.indexOf(" ") === -1)
				msgLength = 1;
			else
				msgLength = message.split(" ").length;

			// maximum response length is 2 more words than the incoming message
			responseLength = Math.ceil(Math.random() * (msgLength + 2));

			// longer sentences should get a comma
			if (responseLength > 8)
				comma = Math.ceil(responseLength / 2);

			// simulated delayed response
			delay = Math.ceil(Math.random() * (responseLength + 1) * 1000) + 2500;
			if (msgLength > 0) { //if user has inputted message then
				var _data = {
					"message": {
						"type": "text",
						"content": message
					},
					"conversation_id": "test-1533969037613",
					"log_level": "info"
				};
				var that = this;
				$.ajax({
					type: "POST",
					data: JSON.stringify(_data),
					url: "https://" + "api.recast.ai/build/v1/dialog",
					contentType: "application/json",
					path: "/build/v1/dialog",
					scheme: "https",
					headers: {         
						"Authorization": "Token cda6c26720b3353f06d2586973b6b5f3",
						"x-uuid": that.uuid
					},
					success: function (data) {
					    // do what you need to 
						that.pqaBotConversation = data;
						if(data.results.messages.length!==0){
						that.createMessage("bot", data.results.messages[0].content, delay);
						}
						else{
							that.createMessage("bot", "I trigger the fallback skill because I don't understand or I don't know what I'm supposed to do...", delay);
						}
					},
					error: function (data) {
						that.botError = data;
					}
				});
			}
			
		},

		onBeforeBotOpen: function () {
			this.isDisplayed = false;
		},

		createMessage: function (from, message, delay) {
			// paragraph
			var sSrc, sStyle;
			var listItem;
			if (from === "bot") {
				sSrc = "https://cdn.recast.ai/webchat/bot.png";
				sStyle = "botStyle";
				listItem = new sap.m.CustomListItem({
					content: [
						new sap.m.Image({
							src: sSrc,
							height: "2rem"
						}), 
						new sap.m.Text({
							text: message
						})
					]
				});
			} else if (from === "user") {
				sSrc = "https://cdn.recast.ai/webchat/user.png";
				sStyle = "userStyle";
				listItem = new sap.m.CustomListItem({
					content: [
						new sap.m.Text({
						text: message
					}), 
					new sap.m.Image({
						src: sSrc,
						height: "2rem"
					})]
				});
			}
			listItem.addStyleClass(sStyle);
			var CompChatList = this.byId(sap.ui.core.Fragment.createId(this.createId("chatBotFragment"), "item1"));

			//CompChatList.addContent(listItem);
	     	CompChatList.getList().addItem(listItem);
	     	this.isTyping = false;
			CompChatList.getModel().refresh();
	
		    /*this._obotFrag.close();
		    this.handleChatButton();*/
		
		},
		
			fnVoiceRecog : function(oEvent) {

		if (this.startedflag === true) {
			this.recognition.stop();
		}
		
		if('webkitSpeechRecognition' in window){
			this.recognition = new webkitSpeechRecognition() ;
		}else{
			this.recognition = new SpeechRecognition();
		}
		
		this.recognition.continuous = true;
		this.recognition.interimResults = false;
		this.recognition.lang = 'en-IN';

		this.recognition.onstart = function() {
		};

		this.recognition.onerror = function(event) {
		};

		this.recognition.onend = function() {
		};

		this.recognition.onresult = function(event) {
			var vFinal = "";
			for (var i = event.resultIndex; i < event.results.length; ++i) {
				if (event.results[i].isFinal) {
					vFinal = event.results[i][0].transcript;
				}
			}
			if (vFinal !== "") {
				sap.m.MessageToast.show(vFinal);
			}
		};

		this.recognition.start();
		this.startedflag = true;

	}

	});
});