sap.ui.define([
	"com/chatbot/Somesh_ChatBot/test/unit/controller/SChat.controller"
], function () {
	"use strict";
});