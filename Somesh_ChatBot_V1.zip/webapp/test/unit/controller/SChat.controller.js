/*global QUnit*/

sap.ui.define([
	"com/chatbot/Somesh_ChatBot/controller/SChat.controller"
], function (oController) {
	"use strict";

	QUnit.module("SChat Controller");

	QUnit.test("I should test the SChat controller", function (assert) {
		var oAppController = new oController();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});